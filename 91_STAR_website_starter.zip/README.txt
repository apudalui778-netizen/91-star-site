91 STAR — Starter Website
=========================

Files
-----
- index.html: page content and sections
- style.css: red/black responsive design
- script.js: mobile navigation and current year

Run locally
-----------
1. Extract the ZIP.
2. Open index.html in a browser.
3. Edit text and contact details in index.html.
4. Change colors in :root at the top of style.css.

Publish free with GitHub Pages
------------------------------
1. Create/sign in to a GitHub account.
2. Create a new public repository, for example `91-star-site`.
3. Upload index.html, style.css and script.js to the repository root.
4. Open repository Settings → Pages.
5. Under Build and deployment, select “Deploy from a branch”.
6. Choose branch `main` and folder `/ (root)`, then Save.
7. Wait for the Pages URL shown in Settings → Pages.

Before publishing
-----------------
- Replace hello@example.com and all sample text with your own accurate details.
- Do not publish private information such as passwords, OTPs, bank details or identity documents.
- This is a static information/brand website. It does not include accounts, payments, betting, or a database.
- Google Fonts are loaded online; the site still has fallback fonts if they are unavailable.
